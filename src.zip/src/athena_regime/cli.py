from __future__ import annotations

import argparse
import dataclasses
import json
import sys
from typing import Any

import pandas as pd

from src.athena_regime.config.loader import load_config
from src.athena_regime.data.ingestion import DEFAULT_UPDATE_DATASETS, prune_dataset, update_dataset
from src.athena_regime.data.lake import DATASET_SPECS, DataLake
from src.athena_regime.data.pipeline import build_feature_matrix, build_prices_matrix
from src.athena_regime.data.providers import MockProvider, provider_from_env
from src.athena_regime.run_context.context import RunContext


def _console():
    try:
        from rich.console import Console

        return Console()
    except ImportError:
        return None


def _print_banner(console, mode: str, run_id: str) -> None:
    try:
        from rich.panel import Panel
        from rich.text import Text

        t = Text()
        t.append("ATHENA", style="bold cyan")
        t.append(f"  mode={mode}  run_id={run_id}", style="dim")
        console.print(Panel(t, border_style="cyan", padding=(0, 2)))
    except ImportError:
        print(f"\n=== ATHENA | mode={mode} | run_id={run_id} ===\n")


def _print_metrics_table(metrics: dict[str, Any], title: str = "Results") -> None:
    console = _console()
    if console is None:
        print(f"\n--- {title} ---")
        for k, v in metrics.items():
            if not isinstance(v, dict):
                print(f"  {k:<30} {v}")
        return
    try:
        from rich import box
        from rich.table import Table

        table = Table(title=title, box=box.ROUNDED, show_header=True, header_style="bold magenta")
        table.add_column("Metric", style="cyan", no_wrap=True)
        table.add_column("Value", justify="right")
        for k, v in metrics.items():
            if isinstance(v, dict):
                continue
            table.add_row(str(k), f"{v:.4f}" if isinstance(v, float) else str(v))
        console.print(table)
    except ImportError:
        print(f"\n--- {title} ---")
        for k, v in metrics.items():
            if not isinstance(v, dict):
                print(f"  {k:<30} {v}")


def _lake_from_cfg(cfg) -> DataLake:
    return DataLake(cfg.data.datastore_root)


def _load_feature_matrix(cfg, ctx):
    lake = _lake_from_cfg(cfg)
    X = build_feature_matrix(lake=lake)
    prices = build_prices_matrix(lake=lake, target_idx=X.index)
    if prices is not None:
        prices = prices.reindex(X.index).ffill(limit=3)
    ctx.logger.info("Loaded feature matrix from gold datasets: shape=%s", X.shape)
    return X, prices


def _cmd_generate(cfg, ctx):
    lake = _lake_from_cfg(cfg)
    provider = MockProvider()
    end = pd.Timestamp.now(tz="UTC").date().isoformat()
    start = (pd.Timestamp(end) - pd.Timedelta(days=1500)).date().isoformat()
    results = {}
    for dataset in DEFAULT_UPDATE_DATASETS:
        results[dataset] = update_dataset(lake=lake, dataset=dataset, provider=provider, start=start, end=end)
    ctx.log_metrics({k: v["status"] for k, v in results.items()})


def _cmd_infer(cfg, ctx):
    from src.athena_regime.features.engineering import RollingZScaler, run_qa
    from src.athena_regime.regimes.inference import RegimeInferenceEngine

    X, _ = _load_feature_matrix(cfg, ctx)
    X, _ = run_qa(X, logger=ctx.logger)
    X = X.replace([float("inf"), float("-inf")], float("nan")).fillna(0.0)

    scaler = RollingZScaler()
    X_z = scaler.fit_transform(X)

    engine = RegimeInferenceEngine(
        n_states=cfg.regime.n_states,
        n_hmm_iter=cfg.regime.n_hmm_iter,
        n_restarts=cfg.regime.n_restarts,
    )
    engine.fit(X_z)
    result_df = engine.infer(X_z)

    out = ctx.artifact("regime_history.parquet")
    result_df.to_parquet(out)
    ctx.logger.info("regime_history written -> %s", out)
    _print_metrics_table({"rows": len(result_df), "states": result_df["state"].nunique()}, title="Infer Complete")


def _cmd_backtest(cfg, ctx):
    from src.athena_regime.backtest.engine import WalkForwardBacktest, WalkForwardConfig
    from src.athena_regime.analytics.visualization import generate_visual_report

    X, prices = _load_feature_matrix(cfg, ctx)
    if prices is None:
        raise RuntimeError("prices not available in gold returns_daily dataset")

    wf_cfg = WalkForwardConfig(
        mode="expanding" if cfg.backtest.expanding else "rolling",
        train_periods=cfg.backtest.train_window,
        step_size=cfg.backtest.step_size,
        n_hmm_iter=cfg.regime.n_hmm_iter,
        n_hmm_restarts=cfg.regime.n_restarts,
        n_states=cfg.regime.n_states,
        prop_cost_bps=cfg.backtest.transaction_cost_bps,
        impact_bps=cfg.backtest.impact_bps,
        bid_ask_bps=cfg.backtest.bid_ask_bps,
        max_leverage=cfg.backtest.max_leverage,
        max_weight=cfg.backtest.max_weight,
        turnover_cap=cfg.backtest.turnover_cap,
        rebal_threshold=cfg.backtest.rebalance_threshold,
        vol_target=cfg.backtest.vol_target,
    )
    print("backtesting")
    bt = WalkForwardBacktest(X, prices, wf_cfg, save_dir=str(ctx.run_dir / "artifacts"))
    result = bt.run()

    metrics = result.performance
    ctx.log_metrics(metrics)
    _print_metrics_table(metrics, title="Backtest Results")

    returns_df = result.daily_returns.to_frame("returns")
    parquet_path = ctx.artifact("backtest_returns.parquet")
    returns_df.to_parquet(parquet_path)
    ctx.logger.info("backtest complete sharpe=%.2f", metrics.get("sharpe", float("nan")))
    viz_outputs = generate_visual_report(cfg.run.runs_dir, run_id=ctx.run_id)
    if viz_outputs:
        ctx.logger.info("visual artifacts: %s", viz_outputs)


def _cmd_stress(cfg, ctx, scenario_name: str | None):
    if not scenario_name:
        raise ValueError("--scenario is required for stress mode")

    from src.athena_regime.backtest.engine import WalkForwardBacktest, WalkForwardConfig
    from src.athena_regime.data.models import FeatureMatrix
    from src.athena_regime.stress.runner import StressTestRunner
    from src.athena_regime.stress.scenarios import ScenarioRegistry

    X, prices = _load_feature_matrix(cfg, ctx)
    if prices is None:
        raise RuntimeError("prices not available in gold returns_daily dataset")

    wf_cfg = WalkForwardConfig(
        mode="expanding" if cfg.backtest.expanding else "rolling",
        train_periods=cfg.backtest.train_window,
        step_size=cfg.backtest.step_size,
        n_hmm_iter=cfg.regime.n_hmm_iter,
        n_hmm_restarts=cfg.regime.n_restarts,
        n_states=cfg.regime.n_states,
        prop_cost_bps=cfg.backtest.transaction_cost_bps,
        impact_bps=cfg.backtest.impact_bps,
        bid_ask_bps=cfg.backtest.bid_ask_bps,
        max_leverage=cfg.backtest.max_leverage,
        max_weight=cfg.backtest.max_weight,
        turnover_cap=cfg.backtest.turnover_cap,
        rebal_threshold=cfg.backtest.rebalance_threshold,
        vol_target=cfg.backtest.vol_target,
    )
    fm = FeatureMatrix(X=X, feature_names=list(X.columns), metadata={})

    def backtest_factory(shocked_fm):
        return WalkForwardBacktest(shocked_fm.X, prices, wf_cfg, save_dir=str(ctx.run_dir / "artifacts")).run()

    scenario = ScenarioRegistry.get(scenario_name)
    runner = StressTestRunner(backtest_factory, ctx)
    result = runner.run(fm, scenario)

    ctx.log_metrics(result.performance)
    _print_metrics_table(result.performance, title=f"Stress: {scenario_name}")
    from src.athena_regime.analytics.visualization import generate_visual_report

    viz_outputs = generate_visual_report(cfg.run.runs_dir, run_id=ctx.run_id)
    if viz_outputs:
        ctx.logger.info("visual artifacts: %s", viz_outputs)


def _cmd_visualize(cfg, ctx, run_id: str | None):
    from src.athena_regime.analytics.visualization import generate_visual_report

    outputs = generate_visual_report(cfg.run.runs_dir, run_id=run_id)
    if not outputs:
        ctx.logger.warning("No visualization outputs produced. Missing run artifacts or plotting dependency.")
        return
    for name, path in outputs.items():
        ctx.logger.info("%s -> %s", name, path)
    _print_metrics_table({"artifacts": len(outputs), **{k: str(v) for k, v in outputs.items()}}, title="Visualize")


def _run_pipeline_command(args) -> int:
    cfg = load_config(args.config)
    ctx = RunContext(cfg, run_id=args.run_id)
    ctx.log_config(dataclasses.asdict(cfg))
    ctx.logger.info("command=%s run_id=%s", args.command, ctx.run_id)

    console = _console()
    if console:
        _print_banner(console, args.command, ctx.run_id)

    try:
        if args.command == "generate":
            _cmd_generate(cfg, ctx)
        elif args.command == "infer":
            _cmd_infer(cfg, ctx)
        elif args.command == "backtest":
            _cmd_backtest(cfg, ctx)
        elif args.command == "stress":
            _cmd_stress(cfg, ctx, args.scenario)
        elif args.command == "visualize":
            _cmd_visualize(cfg, ctx, args.target_run_id)
        else:
            raise ValueError(f"Unknown run command: {args.command}")
    except Exception:
        ctx.logger.exception("Fatal error in command=%s", args.command)
        return 1

    ctx.logger.info("run complete run_id=%s", ctx.run_id)
    return 0


def _run_data_command(args) -> int:
    cfg = load_config(args.config)
    lake = DataLake(cfg.data.datastore_root)

    if args.data_command == "update":
        provider = provider_from_env(args.dataset)
        result = update_dataset(
            lake=lake,
            dataset=args.dataset,
            provider=provider,
            start=args.start,
            end=args.end,
        )
    elif args.data_command == "update-all":
        result = {}
        for dataset in DEFAULT_UPDATE_DATASETS:
            provider = provider_from_env(dataset)
            result[dataset] = update_dataset(
                lake=lake,
                dataset=dataset,
                provider=provider,
                start=args.start,
                end=args.end,
            )
    elif args.data_command == "prune":
        if args.level == "gold" and not args.force_gold:
            raise ValueError("Refusing to prune gold without --force-gold.")
        result = prune_dataset(
            lake=lake,
            dataset=args.dataset,
            level=args.level,
            older_than=args.older_than,
            keep_last_n=args.keep_last_n,
        )
    else:
        raise ValueError(f"Unknown data command: {args.data_command}")

    print(json.dumps(result, indent=2, default=str))
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="athena", description="ATHENA CLI")
    sub = parser.add_subparsers(dest="group", required=True)

    p_run = sub.add_parser("run", help="Run modeling workflows")
    p_run.add_argument("--config", required=True, help="Path to YAML config file")
    p_run.add_argument("--run-id", default=None, help="Override auto-generated run ID")
    run_sub = p_run.add_subparsers(dest="command", required=True)
    run_sub.add_parser("generate", help="Generate synthetic data via MockProvider")
    run_sub.add_parser("infer", help="Run regime inference")
    run_sub.add_parser("backtest", help="Run backtest")
    p_stress = run_sub.add_parser("stress", help="Run stress scenario")
    p_stress.add_argument("--scenario", required=True, help="Stress scenario name")
    p_visualize = run_sub.add_parser("visualize", help="Create run diagnostics and cross-run trend charts")
    p_visualize.add_argument(
        "--target-run-id",
        default=None,
        help="Run ID to visualize for diagnostics panel. Defaults to latest run.",
    )

    p_data = sub.add_parser("data", help="Data lake commands")
    p_data.add_argument("--config", default="configs/base.yaml", help="Path to YAML config file")
    data_sub = p_data.add_subparsers(dest="data_command", required=True)
    p_update = data_sub.add_parser("update", help="Incremental update for one dataset")
    p_update.add_argument("--dataset", required=True, choices=sorted(DATASET_SPECS.keys()))
    p_update.add_argument("--start", default=None)
    p_update.add_argument("--end", default=None)

    p_update_all = data_sub.add_parser("update-all", help="Incremental update for default datasets")
    p_update_all.add_argument("--start", default=None)
    p_update_all.add_argument("--end", default=None)

    p_prune = data_sub.add_parser("prune", help="Prune old partitions")
    p_prune.add_argument("--dataset", required=True, choices=sorted(DATASET_SPECS.keys()))
    p_prune.add_argument("--level", required=True, choices=["bronze", "silver", "gold"])
    p_prune.add_argument("--older-than", default=None)
    p_prune.add_argument("--keep-last-n", type=int, default=None)
    p_prune.add_argument("--force-gold", action="store_true", help="Explicitly allow gold pruning")

    return parser


def main(argv=None) -> int:
    args = _build_parser().parse_args(list(sys.argv[1:] if argv is None else argv))
    if args.group == "run":
        return _run_pipeline_command(args)
    if args.group == "data":
        return _run_data_command(args)
    raise ValueError(f"Unknown command group: {args.group}")


if __name__ == "__main__":
    raise SystemExit(main())
