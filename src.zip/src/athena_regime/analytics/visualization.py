from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd


def _try_import_matplotlib():
    try:
        import matplotlib.dates as mdates
        import matplotlib.pyplot as plt

        return plt, mdates
    except Exception:
        return None, None


def _coerce_datetime_index(df: pd.DataFrame) -> pd.DataFrame:
    if not isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index, utc=True, errors="coerce")
    return df[~df.index.isna()]


def _first_numeric_column(df: pd.DataFrame) -> str | None:
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            return col
        coerced = pd.to_numeric(df[col], errors="coerce")
        if coerced.notna().any():
            df[col] = coerced
            return col
    return None


def _run_ts_from_id(run_id: str) -> datetime | None:
    prefix = run_id.split("_", 1)[0]
    try:
        return datetime.strptime(prefix, "%Y%m%dT%H%M%S")
    except ValueError:
        return None


def _latest_run_dir(runs_dir: Path) -> Path | None:
    candidates = [p for p in runs_dir.iterdir() if p.is_dir()]
    if not candidates:
        return None

    def _key(p: Path):
        parsed = _run_ts_from_id(p.name)
        return parsed or datetime.min

    return sorted(candidates, key=_key)[-1]


def collect_run_metrics(runs_dir: str | Path) -> pd.DataFrame:
    root = Path(runs_dir)
    records: list[dict[str, Any]] = []
    if not root.exists():
        return pd.DataFrame()

    for run_dir in sorted([p for p in root.iterdir() if p.is_dir()]):
        metrics_path = run_dir / "metrics.json"
        if not metrics_path.exists():
            continue
        try:
            payload = json.loads(metrics_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue

        row: dict[str, Any] = {"run_id": run_dir.name, "run_path": str(run_dir)}
        row["run_ts"] = _run_ts_from_id(run_dir.name)
        for key, value in payload.items():
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                row[key] = value
        records.append(row)

    if not records:
        return pd.DataFrame()
    df = pd.DataFrame(records).sort_values(["run_ts", "run_id"]).reset_index(drop=True)
    return df


def plot_run_diagnostics(run_dir: str | Path, output_path: str | Path | None = None) -> Path | None:
    plt, mdates = _try_import_matplotlib()
    if plt is None:
        return None

    run_path = Path(run_dir)
    art = run_path / "artifacts"

    nav_path = art / "nav.csv"
    regime_path = art / "regime_history.csv"
    weights_path = art / "weights_history.csv"
    rebal_path = art / "rebalance_log.csv"
    if not nav_path.exists():
        return None

    nav_df = pd.read_csv(nav_path, index_col=0)
    nav_df = _coerce_datetime_index(nav_df)
    nav_col = nav_df.columns[0]
    nav = nav_df[nav_col].astype(float)
    drawdown = nav / nav.cummax() - 1.0

    regime_df = pd.read_csv(regime_path, index_col=0) if regime_path.exists() else pd.DataFrame()
    if not regime_df.empty:
        regime_df = _coerce_datetime_index(regime_df)

    weights_df = pd.read_csv(weights_path, index_col=0) if weights_path.exists() else pd.DataFrame()
    if not weights_df.empty:
        weights_df = _coerce_datetime_index(weights_df)

    rebal_df = pd.read_csv(rebal_path, index_col=0) if rebal_path.exists() else pd.DataFrame()
    if not rebal_df.empty:
        rebal_df = _coerce_datetime_index(rebal_df)

    fig, axes = plt.subplots(4, 1, figsize=(14, 13), sharex=True, constrained_layout=True)
    ax_nav, ax_reg, ax_w, ax_rebal = axes

    ax_nav.plot(nav.index, nav.values, lw=1.8, color="#1f77b4", label="NAV")
    ax_nav.fill_between(drawdown.index, drawdown.values, 0, color="#d62728", alpha=0.20, label="Drawdown")
    ax_nav.set_title(f"Backtest Diagnostics | {run_path.name}")
    ax_nav.set_ylabel("NAV")
    ax_nav.legend(loc="upper left")
    ax_nav.grid(alpha=0.2)

    if not regime_df.empty and "state" in regime_df.columns:
        states = regime_df["state"].astype(int)
        ax_reg.step(states.index, states.values, where="post", lw=1.6, color="#2ca02c")
        ax_reg.set_ylabel("State")
        ax_reg.set_yticks(sorted(states.unique()))
    ax_reg.grid(alpha=0.2)

    if not weights_df.empty:
        weight_cols = [c for c in weights_df.columns if c != "date"]
        if weight_cols:
            mean_abs = weights_df[weight_cols].abs().mean().sort_values(ascending=False)
            top_cols = list(mean_abs.head(min(6, len(mean_abs))).index)
            for col in top_cols:
                ax_w.plot(weights_df.index, weights_df[col], lw=1.2, label=col)
            ax_w.legend(loc="upper left", ncol=3, fontsize=8)
        ax_w.set_ylabel("Weight")
    ax_w.grid(alpha=0.2)

    if not rebal_df.empty:
        if "distance" in rebal_df.columns:
            ax_rebal.plot(rebal_df.index, rebal_df["distance"], color="#9467bd", lw=1.3, label="JSD Distance")
        if "do_rebalance" in rebal_df.columns:
            marker_points = rebal_df[rebal_df["do_rebalance"] == True]
            if len(marker_points) > 0:
                y = marker_points["distance"] if "distance" in marker_points.columns else 0.0
                ax_rebal.scatter(marker_points.index, y, s=16, color="#ff7f0e", label="Rebalance")
        ax_rebal.legend(loc="upper left")
    ax_rebal.set_ylabel("Rebalance")
    ax_rebal.grid(alpha=0.2)
    ax_rebal.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=6, maxticks=12))
    ax_rebal.xaxis.set_major_formatter(mdates.ConciseDateFormatter(ax_rebal.xaxis.get_major_locator()))

    out_path = Path(output_path) if output_path else art / "run_diagnostics.png"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def plot_returns_with_events(run_dir: str | Path, output_path: str | Path | None = None) -> Path | None:
    plt, mdates = _try_import_matplotlib()
    if plt is None:
        return None

    run_path = Path(run_dir)
    art = run_path / "artifacts"
    returns_path = art / "daily_returns.csv"
    nav_path = art / "nav.csv"
    regime_path = art / "regime_history.csv"
    rebal_path = art / "rebalance_log.csv"
    if not returns_path.exists():
        return None

    returns_df = pd.read_csv(returns_path, index_col=0)
    returns_df = _coerce_datetime_index(returns_df)
    returns_col = _first_numeric_column(returns_df)
    if returns_col is None:
        return None
    returns = returns_df[returns_col].astype(float)
    cumulative_returns = (1.0 + returns).cumprod() - 1.0

    nav = None
    if nav_path.exists():
        nav_df = pd.read_csv(nav_path, index_col=0)
        nav_df = _coerce_datetime_index(nav_df)
        nav_col = _first_numeric_column(nav_df)
        if nav_col is not None:
            nav = nav_df[nav_col].astype(float).reindex(cumulative_returns.index).ffill()
    if nav is None:
        nav = cumulative_returns + 1.0

    regime_df = pd.read_csv(regime_path, index_col=0) if regime_path.exists() else pd.DataFrame()
    if not regime_df.empty:
        regime_df = _coerce_datetime_index(regime_df)

    rebal_df = pd.read_csv(rebal_path, index_col=0) if rebal_path.exists() else pd.DataFrame()
    if not rebal_df.empty:
        rebal_df = _coerce_datetime_index(rebal_df)

    fig, ax = plt.subplots(1, 1, figsize=(14, 6), constrained_layout=True)
    ax2 = ax.twinx()

    ax.plot(cumulative_returns.index, cumulative_returns.values, color="#1f77b4", lw=1.8, label="Cumulative Return")
    ax2.plot(nav.index, nav.values, color="#ff7f0e", lw=1.4, alpha=0.95, label="NAV")
    ax.axhline(0.0, color="#333333", lw=0.8, alpha=0.5)

    trade_dates = pd.DatetimeIndex([])
    if not rebal_df.empty and "do_rebalance" in rebal_df.columns:
        trade_dates = pd.DatetimeIndex(rebal_df[rebal_df["do_rebalance"] == True].index.unique())
    if len(trade_dates) > 0:
        trade_y = cumulative_returns.reindex(trade_dates).dropna()
        ax.scatter(trade_y.index, trade_y.values, s=24, marker="o", color="#ff7f0e", label="Trade/Rebalance")

    regime_change_dates = pd.DatetimeIndex([])
    if not regime_df.empty:
        state_col = "state" if "state" in regime_df.columns else ("label" if "label" in regime_df.columns else None)
        if state_col is not None:
            regime_series = regime_df[state_col]
            changes = regime_series.ne(regime_series.shift(1))
            regime_change_dates = pd.DatetimeIndex(regime_series.index[changes.fillna(False)])
            if len(regime_change_dates) > 0:
                for dt in regime_change_dates:
                    ax.axvline(dt, color="#2ca02c", lw=0.8, alpha=0.25)
                rc_y = cumulative_returns.reindex(regime_change_dates).dropna()
                if len(rc_y) > 0:
                    ax.scatter(rc_y.index, rc_y.values, s=22, marker="x", color="#2ca02c", label="Regime Change")

    ax.set_title(f"Backtest Return Evolution + NAV | {run_path.name}")
    ax.set_ylabel("Cumulative Return")
    ax2.set_ylabel("NAV")
    ax.grid(alpha=0.2)
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="upper left")
    locator = mdates.AutoDateLocator(minticks=6, maxticks=12)
    ax.xaxis.set_major_locator(locator)
    ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))

    out_path = Path(output_path) if output_path else art / "returns_nav.png"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=160)
    plt.close(fig)
    return out_path


def plot_cross_run_trends(
    runs_dir: str | Path,
    output_path: str | Path | None = None,
    metrics: tuple[str, ...] = ("sharpe", "cagr", "max_drawdown", "ann_vol"),
) -> tuple[Path | None, pd.DataFrame]:
    plt, mdates = _try_import_matplotlib()
    df = collect_run_metrics(runs_dir)
    if df.empty:
        return None, df

    if "run_ts" not in df.columns or df["run_ts"].isna().all():
        df["run_ts"] = pd.RangeIndex(start=1, stop=len(df) + 1)
    if plt is None:
        return None, df

    fig, axes = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
    ax_list = [axes[0, 0], axes[0, 1], axes[1, 0], axes[1, 1]]
    selected = list(metrics)[:4]

    for i, metric in enumerate(selected):
        ax = ax_list[i]
        if metric in df.columns:
            ax.plot(df["run_ts"], df[metric], marker="o", lw=1.5, ms=4, color="#1f77b4")
            ax.set_title(metric)
            ax.grid(alpha=0.25)
        else:
            ax.set_title(f"{metric} (missing)")
            ax.grid(alpha=0.25)

    for ax in ax_list:
        if len(df) > 0 and isinstance(df["run_ts"].iloc[0], datetime):
            locator = mdates.AutoDateLocator(minticks=4, maxticks=8)
            ax.xaxis.set_major_locator(locator)
            ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
            ax.tick_params(axis="x", rotation=15)
        else:
            ax.set_xlabel("Run Order")

    root = Path(runs_dir)
    out_path = Path(output_path) if output_path else root / "run_metrics_trends.png"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path, df


def generate_visual_report(
    runs_dir: str | Path,
    run_id: str | None = None,
) -> dict[str, str]:
    runs_root = Path(runs_dir)
    run_dir = (runs_root / run_id) if run_id else _latest_run_dir(runs_root)
    outputs: dict[str, str] = {}

    plt, _ = _try_import_matplotlib()
    if plt is None:
        outputs["plotting_backend"] = "missing: install matplotlib to generate PNG charts"

    if run_dir and run_dir.exists():
        events_plot = plot_returns_with_events(run_dir, output_path=run_dir / "artifacts" / "returns_nav.png")
        if events_plot:
            outputs["returns_nav"] = str(events_plot)

        run_plot = plot_run_diagnostics(run_dir, output_path=run_dir / "artifacts" / "run_diagnostics.png")
        if run_plot:
            outputs["run_diagnostics"] = str(run_plot)

        _, summary_df = plot_cross_run_trends(runs_root, output_path=run_dir / "artifacts" / "run_metrics_trends.png")
        if not summary_df.empty:
            csv_path = run_dir / "artifacts" / "run_metrics_summary.csv"
            summary_df.to_csv(csv_path, index=False)
            outputs["run_metrics_summary"] = str(csv_path)

    return outputs
